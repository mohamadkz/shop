<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">

    <title>پرداخت موفق</title>
</head>

<body>

    <h2>
        سلام <?php echo e($payment->user->name); ?>

    </h2>

    <p>
        پرداخت شما با موفقیت انجام شد.
    </p>

    <hr>

    <p>
        <strong>شماره سفارش:</strong>
        <?php echo e($payment->order->id); ?>

    </p>

    <p>
        <strong>مبلغ پرداخت:</strong>
        <?php echo e(number_format((float) $payment->amount)); ?>

        تومان
    </p>

    <p>
        <strong>شماره پیگیری:</strong>
        <?php echo e($payment->ref_id ?? '---'); ?>

    </p>

    <p>
        <strong>تاریخ پرداخت:</strong>
        <?php echo e($payment->paid_at?->format('Y-m-d H:i')); ?>

    </p>

    <hr>

    <p>
        از خرید شما متشکریم
    </p>

</body>

</html><?php /**PATH C:\laragon\www\test\Shop\resources\views/email/payment-success.blade.php ENDPATH**/ ?>